<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiJiraSyncBundle\Service;

use Symfony\Contracts\HttpClient\Exception\ExceptionInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

final class LicenseClient implements LicenseClientInterface
{
    private const ACTIVATE_PATH = '/api/licenses/activate';
    private const VERIFY_PATH = '/api/licenses/verify';

    public function __construct(
        private readonly HttpClientInterface $httpClient,
        private readonly string $licenseServerUrl,
    ) {
    }

    public function activate(string $licenseKey, string $instanceId): LicenseResponse
    {
        try {
            $response = $this->httpClient->request('POST', $this->licenseServerUrl . self::ACTIVATE_PATH, [
                'json' => [
                    'license_key' => $licenseKey,
                    'instance_id' => $instanceId,
                ],
                'timeout' => 10,
            ]);

            return LicenseResponse::fromArray($response->toArray(false));
        } catch (ExceptionInterface $e) {
            throw new LicenseException('License activation failed: ' . $e->getMessage(), previous: $e);
        }
    }

    public function verify(string $licenseKey, string $instanceId): LicenseResponse
    {
        try {
            $response = $this->httpClient->request('POST', $this->licenseServerUrl . self::VERIFY_PATH, [
                'json' => [
                    'license_key' => $licenseKey,
                    'instance_id' => $instanceId,
                ],
                'timeout' => 10,
            ]);

            return LicenseResponse::fromArray($response->toArray(false));
        } catch (ExceptionInterface $e) {
            throw new LicenseException('License verification failed: ' . $e->getMessage(), previous: $e);
        }
    }
}
