<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiJiraSyncBundle\Service;

final class LicenseException extends \RuntimeException
{
}
