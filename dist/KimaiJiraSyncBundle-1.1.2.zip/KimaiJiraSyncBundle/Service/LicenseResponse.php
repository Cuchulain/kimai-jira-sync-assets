<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiJiraSyncBundle\Service;

final class LicenseResponse
{
    public function __construct(
        public readonly bool $valid,
        public readonly string $status,
        public readonly ?\DateTimeImmutable $expiresAt,
    ) {
    }

    /**
     * @param array<string, mixed> $data
     */
    public static function fromArray(array $data): self
    {
        $expiresAt = null;
        if (isset($data['expires_at']) && $data['expires_at'] !== null) {
            try {
                $expiresAt = new \DateTimeImmutable((string) $data['expires_at']);
            } catch (\Throwable) {
                $expiresAt = null;
            }
        }

        return new self(
            valid: (bool) ($data['valid'] ?? false),
            status: (string) ($data['status'] ?? 'invalid'),
            expiresAt: $expiresAt,
        );
    }
}
