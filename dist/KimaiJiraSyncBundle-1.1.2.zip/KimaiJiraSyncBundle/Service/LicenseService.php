<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiJiraSyncBundle\Service;

use KimaiPlugin\KimaiJiraSyncBundle\Entity\LicenseActivation;
use KimaiPlugin\KimaiJiraSyncBundle\Repository\JiraCredentialRepositoryInterface;
use KimaiPlugin\KimaiJiraSyncBundle\Repository\LicenseActivationRepositoryInterface;

final class LicenseService implements FreemiumGuardInterface
{
    public function __construct(
        private readonly LicenseClientInterface $licenseClient,
        private readonly LicenseActivationRepositoryInterface $repository,
        private readonly JiraCredentialRepositoryInterface $credentialRepository,
        private readonly string $instanceId = '',
    ) {
    }

    private function resolveInstanceId(): string
    {
        if ($this->instanceId !== '') {
            return $this->instanceId;
        }

        return (string) (gethostname() ?: 'unknown');
    }

    /**
     * Activate a license key against the remote license server and persist the result.
     *
     * @throws LicenseException when the remote call fails or the license is not valid
     */
    public function activate(string $licenseKey): LicenseActivation
    {
        $instanceId = $this->resolveInstanceId();
        $response = $this->licenseClient->activate($licenseKey, $instanceId);

        if (!$response->valid) {
            throw new LicenseException('License key is not valid or could not be activated.');
        }

        $this->repository->deleteAll();

        $activation = new LicenseActivation(
            licenseKey: $licenseKey,
            instanceId: $instanceId,
            status: $response->status,
            expiresAt: $response->expiresAt,
        );
        $activation->setLastVerifiedAt(new \DateTimeImmutable());

        $this->repository->save($activation);

        return $activation;
    }

    /**
     * Verify the currently stored license against the remote license server.
     *
     * @throws LicenseException when no license is stored, or the remote call fails
     */
    public function verify(): LicenseActivation
    {
        $activation = $this->repository->findLatest();

        if ($activation === null) {
            throw new LicenseException('No license found. Please activate a license first.');
        }

        $response = $this->licenseClient->verify($activation->getLicenseKey(), $this->resolveInstanceId());

        $activation->setStatus($response->status);
        $activation->setExpiresAt($response->expiresAt);
        $activation->setLastVerifiedAt(new \DateTimeImmutable());

        $this->repository->save($activation);

        return $activation;
    }

    public function getCurrent(): ?LicenseActivation
    {
        return $this->repository->findLatest();
    }

    public function isLicenseActive(): bool
    {
        $activation = $this->repository->findLatest();

        return $activation !== null && $activation->isActive();
    }

    /**
     * Returns the project ID that is included in the free tier,
     * or null if no project has been configured yet.
     */
    public function getFreeProjectId(): ?int
    {
        return $this->credentialRepository->findLowestProjectId();
    }

    /**
     * Returns true if the given project is allowed to use Jira sync.
     *
     * With an active license all projects are allowed.
     * Without a license only the first (lowest-ID) configured project is allowed for free.
     */
    public function isProjectAllowed(int $projectId): bool
    {
        if ($this->isLicenseActive()) {
            return true;
        }

        $lowestProjectId = $this->credentialRepository->findLowestProjectId();

        // No project configured yet → allow (this will become the free project)
        if ($lowestProjectId === null) {
            return true;
        }

        return $projectId === $lowestProjectId;
    }
}
